#!/usr/bin/env python3
from brain_games.games.engine import welcome_user, hello

def main():
    hello()
    welcome_user()


if __name__ == "__main__":
    main()
