### Hexlet tests and linter status:

[![Actions Status](https://github.com/TechnoPr0/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/TechnoPr0/python-project-49/actions)

<a href="https://codeclimate.com/github/TechnoPr0/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/c9da0c762e1cebfe0305/maintainability" /></a>
